import random
import sqlite3
from datetime import datetime, timezone

import discord

from database import connect, get_dragon
from utils import clamp, get_stage

RARITY_ORDER = ["Common", "Uncommon", "Rare", "Epic", "Legendary", "Mythic"]
RARITY_EMOJI = {
    "Common": "⚪",
    "Uncommon": "🟢",
    "Rare": "🔵",
    "Epic": "🟣",
    "Legendary": "🟠",
    "Mythic": "🔴",
}

LOCATIONS = {
    "forest": {
        "name": "Forest Trail",
        "emoji": "🌲",
        "min_stage": "Hatchling",
        "energy": 8,
        "xp": (35, 75),
        "tokens": (8, 20),
        "difficulty": 1,
        "events": ["found a mossy chest", "tracked fireflies", "met a friendly sprite", "chased a shiny beetle"],
    },
    "mountains": {
        "name": "Mountain Cave",
        "emoji": "⛰️",
        "min_stage": "Hatchling",
        "energy": 12,
        "xp": (60, 120),
        "tokens": (15, 35),
        "difficulty": 2,
        "events": ["found echo crystals", "climbed a windy cliff", "dodged falling stones", "slept near a warm cave wall"],
    },
    "volcano": {
        "name": "Volcano Path",
        "emoji": "🌋",
        "min_stage": "Young Dragon",
        "energy": 18,
        "xp": (110, 220),
        "tokens": (30, 65),
        "difficulty": 4,
        "events": ["bathed in warm ash", "challenged a lava imp", "found obsidian scales", "crossed a cracked fire bridge"],
    },
    "frozen_peaks": {
        "name": "Frozen Peaks",
        "emoji": "❄️",
        "min_stage": "Adult Dragon",
        "energy": 22,
        "xp": (170, 320),
        "tokens": (45, 90),
        "difficulty": 5,
        "events": ["survived a snowstorm", "found an ice shrine", "rescued a lost hatchling", "fought a frost wolf"],
    },
    "ancient_ruins": {
        "name": "Ancient Ruins",
        "emoji": "🏰",
        "min_stage": "Adult Dragon",
        "energy": 25,
        "xp": (220, 450),
        "tokens": (70, 140),
        "difficulty": 6,
        "events": ["decoded old dragon runes", "opened a sealed vault", "awakened a stone guardian", "found a forgotten mural"],
    },
}

EQUIPMENT = {
    "wooden_collar": {"name": "Wooden Collar", "rarity": "Common", "slot": "neck", "energy": 2, "strength": 1},
    "lucky_charm": {"name": "Lucky Charm", "rarity": "Uncommon", "slot": "charm", "luck": 4},
    "iron_collar": {"name": "Iron Collar", "rarity": "Rare", "slot": "neck", "strength": 4, "defense": 3},
    "fire_crystal": {"name": "Fire Crystal", "rarity": "Epic", "slot": "charm", "strength": 6, "intelligence": 3},
    "dragon_armor": {"name": "Dragon Armor", "rarity": "Legendary", "slot": "armor", "defense": 9, "energy": 5},
    "emerald_ring": {"name": "Emerald Ring", "rarity": "Mythic", "slot": "ring", "luck": 10, "intelligence": 8, "energy": 8},
}

QUESTS = {
    "first_steps": {"name": "First Steps", "target": 3, "reward_tokens": 75, "reward_xp": 150},
    "treasure_hunter": {"name": "Treasure Hunter", "target": 10, "reward_tokens": 250, "reward_xp": 500},
    "guild_explorer": {"name": "Guild Explorer", "target": 25, "reward_tokens": 750, "reward_xp": 1500},
}

STAGE_RANK = {
    "Egg": 0,
    "Hatchling": 1,
    "Young Dragon": 2,
    "Adult Dragon": 3,
    "Ancient Dragon": 4,
    "Elder Dragon": 5,
}


def _dict_row(con):
    con.row_factory = sqlite3.Row
    return con


def ensure_adventure_tables():
    con = connect()
    cur = con.cursor()
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS inventory (
            guild_id INTEGER NOT NULL,
            item_key TEXT NOT NULL,
            quantity INTEGER NOT NULL DEFAULT 0,
            equipped INTEGER NOT NULL DEFAULT 0,
            PRIMARY KEY (guild_id, item_key)
        )
        """
    )
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS adventure_stats (
            guild_id INTEGER PRIMARY KEY,
            total_adventures INTEGER NOT NULL DEFAULT 0,
            bosses_defeated INTEGER NOT NULL DEFAULT 0,
            rare_finds INTEGER NOT NULL DEFAULT 0,
            last_result TEXT
        )
        """
    )
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS quest_progress (
            guild_id INTEGER NOT NULL,
            quest_key TEXT NOT NULL,
            progress INTEGER NOT NULL DEFAULT 0,
            completed INTEGER NOT NULL DEFAULT 0,
            claimed INTEGER NOT NULL DEFAULT 0,
            PRIMARY KEY (guild_id, quest_key)
        )
        """
    )
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS adventure_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            guild_id INTEGER NOT NULL,
            user_id INTEGER NOT NULL,
            location_key TEXT NOT NULL,
            result TEXT NOT NULL,
            created_at TEXT NOT NULL
        )
        """
    )
    con.commit()
    con.close()


def _equipped_items(guild_id: int):
    ensure_adventure_tables()
    con = connect()
    con.row_factory = sqlite3.Row
    cur = con.cursor()
    cur.execute("SELECT item_key FROM inventory WHERE guild_id=? AND equipped=1", (guild_id,))
    rows = cur.fetchall()
    con.close()
    return [row["item_key"] for row in rows]


def _equipment_bonus(guild_id: int):
    bonus = {"strength": 0, "defense": 0, "agility": 0, "luck": 0, "intelligence": 0, "energy": 0}
    for key in _equipped_items(guild_id):
        item = EQUIPMENT.get(key, {})
        for stat in bonus:
            bonus[stat] += int(item.get(stat, 0))
    return bonus


def calculated_dragon_stats(guild_id: int):
    d = get_dragon(guild_id)
    stage, _ = get_stage(d["xp"])
    stage_bonus = STAGE_RANK.get(stage, 0) * 6
    gear = _equipment_bonus(guild_id)

    return {
        "stage": stage,
        "health": 80 + stage_bonus + d["bond"] // 5 + gear.get("defense", 0),
        "energy": clamp(d["energy"] + gear.get("energy", 0), 0, 130),
        "strength": 8 + stage_bonus + d["bond"] // 8 + gear.get("strength", 0),
        "defense": 8 + stage_bonus + d["cleanliness"] // 12 + gear.get("defense", 0),
        "agility": 8 + stage_bonus + d["happiness"] // 10 + gear.get("agility", 0),
        "luck": 5 + d["bond"] // 10 + gear.get("luck", 0),
        "intelligence": 6 + stage_bonus + gear.get("intelligence", 0),
    }


def rarity_roll(luck: int):
    roll = random.random() * 100
    # Luck gently improves rare drops without becoming silly.
    roll -= min(20, luck * 0.35)
    if roll <= 1:
        return "Mythic"
    if roll <= 4:
        return "Legendary"
    if roll <= 12:
        return "Epic"
    if roll <= 28:
        return "Rare"
    if roll <= 55:
        return "Uncommon"
    return "Common"


def _add_item(guild_id: int, item_key: str, qty: int = 1):
    ensure_adventure_tables()
    con = connect()
    cur = con.cursor()
    cur.execute(
        """
        INSERT INTO inventory (guild_id, item_key, quantity, equipped)
        VALUES (?, ?, ?, 0)
        ON CONFLICT(guild_id, item_key) DO UPDATE SET quantity = quantity + excluded.quantity
        """,
        (guild_id, item_key, qty),
    )
    con.commit()
    con.close()


def _pick_item_for_rarity(rarity: str):
    matching = [key for key, item in EQUIPMENT.items() if item["rarity"] == rarity]
    if not matching:
        matching = list(EQUIPMENT.keys())
    return random.choice(matching)


def _update_quests(guild_id: int, xp_reward: int, token_reward: int):
    ensure_adventure_tables()
    completed_now = []
    con = connect()
    cur = con.cursor()
    for key, q in QUESTS.items():
        cur.execute(
            """
            INSERT INTO quest_progress (guild_id, quest_key, progress, completed, claimed)
            VALUES (?, ?, 0, 0, 0)
            ON CONFLICT(guild_id, quest_key) DO NOTHING
            """,
            (guild_id, key),
        )
        cur.execute("SELECT progress, completed FROM quest_progress WHERE guild_id=? AND quest_key=?", (guild_id, key))
        row = cur.fetchone()
        progress, completed = row[0], row[1]
        if completed:
            continue
        progress += 1
        completed = 1 if progress >= q["target"] else 0
        cur.execute(
            "UPDATE quest_progress SET progress=?, completed=? WHERE guild_id=? AND quest_key=?",
            (progress, completed, guild_id, key),
        )
        if completed:
            completed_now.append(key)
    con.commit()
    con.close()
    return completed_now


def run_adventure(guild_id: int, user, location_key: str):
    ensure_adventure_tables()
    location = LOCATIONS[location_key]
    d = get_dragon(guild_id)
    stats = calculated_dragon_stats(guild_id)
    stage = stats["stage"]

    if STAGE_RANK.get(stage, 0) < STAGE_RANK.get(location["min_stage"], 0):
        return False, f"🔒 **{location['name']}** unlocks at **{location['min_stage']}**.", None

    energy_cost = location["energy"]
    if d["energy"] < energy_cost:
        return False, f"⚡ The dragon needs **{energy_cost}% energy** for this adventure. Current energy: **{d['energy']}%**.", None

    power = stats["strength"] + stats["defense"] + stats["agility"] + stats["intelligence"] + stats["luck"]
    target = 35 + (location["difficulty"] * 22)
    success_chance = clamp(55 + (power - target), 20, 92)
    success = random.randint(1, 100) <= success_chance
    boss = random.random() < (0.08 + min(0.10, stats["luck"] / 400))

    xp_min, xp_max = location["xp"]
    token_min, token_max = location["tokens"]
    xp = random.randint(xp_min, xp_max)
    tokens = random.randint(token_min, token_max)
    if not success:
        xp = max(5, xp // 3)
        tokens = max(2, tokens // 4)
    if boss and success:
        xp *= 2
        tokens *= 2

    found_item_key = None
    rarity = None
    if success and random.random() < 0.35:
        rarity = rarity_roll(stats["luck"])
        found_item_key = _pick_item_for_rarity(rarity)
        _add_item(guild_id, found_item_key, 1)

    event_text = random.choice(location["events"])
    result_title = "Victory" if success else "Narrow Escape"
    if boss and success:
        result_title = "Boss Defeated"

    con = connect()
    cur = con.cursor()
    cur.execute(
        """
        UPDATE dragon
        SET energy=?, happiness=?, bond=?, xp=?, guild_tokens=?, lifetime_guild_tokens=?,
            pose=?, visual_event=?, dragon_message=?, last_action_text=?
        WHERE guild_id=?
        """,
        (
            clamp(d["energy"] - energy_cost),
            clamp(d["happiness"] + (4 if success else -2)),
            clamp(d["bond"] + (3 if success else 1)),
            d["xp"] + xp,
            d["guild_tokens"] + tokens,
            d["lifetime_guild_tokens"] + tokens,
            "adventuring",
            "None",
            f"I returned from {location['name']}!",
            f"**{user.display_name}** sent the dragon to **{location['name']}** — {result_title}.",
            guild_id,
        ),
    )
    cur.execute(
        """
        INSERT INTO adventure_stats (guild_id, total_adventures, bosses_defeated, rare_finds, last_result)
        VALUES (?, 1, ?, ?, ?)
        ON CONFLICT(guild_id) DO UPDATE SET
            total_adventures = total_adventures + 1,
            bosses_defeated = bosses_defeated + excluded.bosses_defeated,
            rare_finds = rare_finds + excluded.rare_finds,
            last_result = excluded.last_result
        """,
        (guild_id, 1 if boss and success else 0, 1 if found_item_key else 0, result_title),
    )
    cur.execute(
        "INSERT INTO adventure_log (guild_id, user_id, location_key, result, created_at) VALUES (?, ?, ?, ?, ?)",
        (guild_id, user.id, location_key, result_title, datetime.now(timezone.utc).isoformat()),
    )
    con.commit()
    con.close()

    completed = _update_quests(guild_id, xp, tokens)

    embed = discord.Embed(
        title=f"{location['emoji']} Adventure: {location['name']}",
        description=f"**{result_title}!** The dragon {event_text}.",
        colour=discord.Colour.green() if success else discord.Colour.orange(),
    )
    embed.add_field(name="Rewards", value=f"⭐ XP: **{xp}**\n🪙 Guild Tokens: **{tokens}**", inline=True)
    embed.add_field(name="Energy", value=f"⚡ -{energy_cost}%", inline=True)
    embed.add_field(name="Success Chance", value=f"🎯 {success_chance}%", inline=True)

    if found_item_key:
        item = EQUIPMENT[found_item_key]
        embed.add_field(
            name="Loot Found",
            value=f"{RARITY_EMOJI[item['rarity']]} **{item['name']}**\n*{item['rarity']} {item['slot']}*",
            inline=False,
        )
    if completed:
        quest_lines = [f"📜 **{QUESTS[key]['name']}** completed!" for key in completed]
        embed.add_field(name="Quest Progress", value="\n".join(quest_lines), inline=False)
    if boss and success:
        embed.add_field(name="Boss", value="👹 A boss was defeated during this adventure!", inline=False)

    return True, None, embed


def make_adventure_embed(guild_id: int):
    ensure_adventure_tables()
    stats = calculated_dragon_stats(guild_id)
    d = get_dragon(guild_id)
    embed = discord.Embed(
        title="🗺️ Choose an Adventure",
        description="Send the guild dragon on a quick adventure. Higher areas cost more energy but give better rewards.",
        colour=discord.Colour.blurple(),
    )
    embed.add_field(
        name="Dragon Stats",
        value=(
            f"❤️ Health: **{stats['health']}**\n"
            f"⚡ Energy: **{d['energy']}%**\n"
            f"💪 Strength: **{stats['strength']}**\n"
            f"🛡 Defense: **{stats['defense']}**\n"
            f"🏃 Agility: **{stats['agility']}**\n"
            f"🍀 Luck: **{stats['luck']}**\n"
            f"🧠 Intelligence: **{stats['intelligence']}**"
        ),
        inline=False,
    )
    for key, loc in LOCATIONS.items():
        locked = STAGE_RANK.get(stats["stage"], 0) < STAGE_RANK.get(loc["min_stage"], 0)
        status = f"🔒 unlocks at {loc['min_stage']}" if locked else f"⚡ {loc['energy']} energy"
        embed.add_field(
            name=f"{loc['emoji']} {loc['name']}",
            value=f"{status}\n⭐ {loc['xp'][0]}-{loc['xp'][1]} XP | 🪙 {loc['tokens'][0]}-{loc['tokens'][1]} tokens",
            inline=False,
        )
    return embed


def make_inventory_embed(guild_id: int):
    ensure_adventure_tables()
    con = connect()
    con.row_factory = sqlite3.Row
    cur = con.cursor()
    cur.execute("SELECT item_key, quantity, equipped FROM inventory WHERE guild_id=? ORDER BY equipped DESC, item_key", (guild_id,))
    rows = cur.fetchall()
    con.close()

    embed = discord.Embed(title="🎒 Dragon Inventory", colour=discord.Colour.dark_teal())
    if not rows:
        embed.description = "No equipment yet. Send the dragon on adventures to find loot."
        return embed

    lines = []
    for row in rows:
        item = EQUIPMENT.get(row["item_key"])
        if not item:
            continue
        equipped = " ✅ equipped" if row["equipped"] else ""
        bonuses = []
        for stat in ["strength", "defense", "agility", "luck", "intelligence", "energy"]:
            if item.get(stat):
                bonuses.append(f"+{item[stat]} {stat}")
        lines.append(f"{RARITY_EMOJI[item['rarity']]} **{item['name']}** x{row['quantity']}{equipped}\n*{item['rarity']} {item['slot']}* — {', '.join(bonuses)}")
    embed.description = "\n\n".join(lines[:15])
    return embed


def make_quests_embed(guild_id: int):
    ensure_adventure_tables()
    con = connect()
    cur = con.cursor()
    lines = []
    for key, q in QUESTS.items():
        cur.execute(
            """
            INSERT INTO quest_progress (guild_id, quest_key, progress, completed, claimed)
            VALUES (?, ?, 0, 0, 0)
            ON CONFLICT(guild_id, quest_key) DO NOTHING
            """,
            (guild_id, key),
        )
        cur.execute("SELECT progress, completed FROM quest_progress WHERE guild_id=? AND quest_key=?", (guild_id, key))
        progress, completed = cur.fetchone()
        status = "✅ completed" if completed else f"{min(progress, q['target'])}/{q['target']}"
        lines.append(f"📜 **{q['name']}** — {status}\nReward: ⭐ {q['reward_xp']} XP | 🪙 {q['reward_tokens']} tokens")
    con.commit()
    con.close()
    embed = discord.Embed(title="📜 Dragon Quests", description="\n\n".join(lines), colour=discord.Colour.gold())
    return embed


def make_lair_embed(guild_id: int):
    stats = calculated_dragon_stats(guild_id)
    d = get_dragon(guild_id)
    embed = discord.Embed(
        title="🏡 Dragon Lair",
        description="Overview of the dragon's condition, derived RPG stats, and guild progress.",
        colour=discord.Colour.green(),
    )
    embed.add_field(name="Care", value=f"🍖 Hunger: {d['hunger']}%\n😊 Happiness: {d['happiness']}%\n⚡ Energy: {d['energy']}%\n🛁 Cleanliness: {d['cleanliness']}%\n❤️ Bond: {d['bond']}%", inline=True)
    embed.add_field(name="Battle Stats", value=f"❤️ Health: {stats['health']}\n💪 Strength: {stats['strength']}\n🛡 Defense: {stats['defense']}\n🏃 Agility: {stats['agility']}\n🍀 Luck: {stats['luck']}\n🧠 Intelligence: {stats['intelligence']}", inline=True)
    embed.add_field(name="Stage", value=f"🐉 {stats['stage']}\n⭐ XP: {d['xp']}\n🪙 Guild tokens: {d['guild_tokens']}", inline=False)
    return embed
