import discord

from adventures import LOCATIONS, make_adventure_embed, run_adventure
from views.updater import update_dragon_message


class AdventureSelect(discord.ui.Select):
    def __init__(self):
        options = []
        for key, loc in LOCATIONS.items():
            options.append(
                discord.SelectOption(
                    label=loc["name"],
                    value=key,
                    emoji=loc["emoji"],
                    description=f"{loc['energy']} energy • unlocks at {loc['min_stage']}",
                )
            )
        super().__init__(placeholder="Choose an adventure location", options=options, min_values=1, max_values=1)

    async def callback(self, interaction: discord.Interaction):
        location_key = self.values[0]
        ok, error, embed = run_adventure(interaction.guild.id, interaction.user, location_key)
        if not ok:
            await interaction.response.send_message(error, ephemeral=True)
            return

        await interaction.response.edit_message(embed=embed, view=AdventureAgainView())
        await update_dragon_message(interaction.guild)


class AdventureView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=180)
        self.add_item(AdventureSelect())

    @discord.ui.button(label="Cancel", emoji="❌", style=discord.ButtonStyle.secondary)
    async def cancel(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.edit_message(content="Adventure cancelled.", embed=None, view=None)


class AdventureAgainView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=180)

    @discord.ui.button(label="Adventure Again", emoji="🗺️", style=discord.ButtonStyle.primary)
    async def again(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.edit_message(embed=make_adventure_embed(interaction.guild.id), view=AdventureView())

    @discord.ui.button(label="Close", emoji="❌", style=discord.ButtonStyle.secondary)
    async def close(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.edit_message(view=None)
